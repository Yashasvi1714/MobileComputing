package com.example.assignment3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class NoteDetailFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_note_detail, container, false);
        TextView noteContentTextView = view.findViewById(R.id.noteContentTextView);

        assert getArguments() != null;
        String noteContent = getArguments().getString("note_content");
        if (noteContent != null) {
            noteContentTextView.setText(noteContent);
        }

        return view;
    }
}
