package com.example.assignment3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ArrayAdapter<String> noteAdapter;
    private List<String> notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView noteListView = findViewById(R.id.noteListView);
        notes = new ArrayList<>();
        noteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notes);
        noteListView.setAdapter(noteAdapter);

        noteListView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedNote = notes.get(position);
            openNoteDetailActivity(selectedNote);
        });

        Button addNoteButton = findViewById(R.id.addNoteButton);
        addNoteButton.setOnClickListener(v -> openAddNoteActivity());

        loadNotes();
    }

    private void openNoteDetailActivity(String selectedNote) {
        Intent intent = new Intent(this, NoteDetailActivity.class);
        intent.putExtra("note_content", selectedNote);
        startActivity(intent);
    }

    private void openAddNoteActivity() {
        Intent intent = new Intent(this, AddNoteActivity.class);
        startActivityForResult(intent, 1); // Request code 1 for AddNoteActivity
    }

    private void loadNotes() {
        try {
            FileInputStream fileInputStream = openFileInput("notes.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                notes.add(line);
            }
            noteAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            String newNote = data.getStringExtra("new_note");
            if (newNote != null) {
                notes.add(newNote);
                noteAdapter.notifyDataSetChanged();
                saveNoteToFile(newNote);
            }
        }
    }

    private void saveNoteToFile(String note) {
        try {
            FileOutputStream fos = openFileOutput("notes.txt", MODE_APPEND);
            fos.write(note.getBytes());
            fos.write("\n".getBytes()); // Separate notes by a new line
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
