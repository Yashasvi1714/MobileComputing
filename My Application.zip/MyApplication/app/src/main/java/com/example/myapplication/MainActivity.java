package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumber1, editTextNumber2;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editTextNumber1 = findViewById(R.id.editTextNumber1);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        Button buttonAdd = findViewById(R.id.buttonAdd);
        Button buttonSubtract = findViewById(R.id.buttonSubtract);
        Button buttonMultiply = findViewById(R.id.buttonMultiply);
        Button buttonDivide = findViewById(R.id.buttonDivide);
        textViewResult = findViewById(R.id.textViewResult);

        // Set click listeners for operation buttons
        buttonAdd.setOnClickListener(v -> calculateResult("+"));

        buttonSubtract.setOnClickListener(v -> calculateResult("-"));

        buttonMultiply.setOnClickListener(v -> calculateResult("*"));

        buttonDivide.setOnClickListener(v -> calculateResult("/"));
    }

    @SuppressLint("SetTextI18n")
    private void calculateResult(String operator) {
        try {
            double n1 = Double.parseDouble(editTextNumber1.getText().toString());
            double n2 = Double.parseDouble(editTextNumber2.getText().toString());
            double result = 0;

            switch (operator) {
                case "+":
                    result = n1 + n2;
                    break;
                case "-":
                    result = n1 - n2;
                    break;
                case "*":
                    result = n1 * n2;
                    break;
                case "/":
                    if (n2 != 0) {
                        result = n1 / n2;
                    } else {
                        textViewResult.setText("Cannot divide by zero");
                        return;
                    }
                    break;
            }

            textViewResult.setText("Result: " + result);
        } catch (NumberFormatException e) {
            textViewResult.setText("Invalid input");
        }
    }
}
