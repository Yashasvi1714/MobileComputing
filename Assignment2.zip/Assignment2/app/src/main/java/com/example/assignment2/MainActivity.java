package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    public final static String FRUIT_NAME = "FruitName";
    ListView simpleList;
    ArrayList<Item> fruitList = new ArrayList<>();
    HashMap<String, String> fruitData = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fruitData.put("Apple", "Apples are crisp and juicy fruits known for their sweet and slightly tart flavor. They come in a variety of colors, including red, green, and yellow. Apples are not only delicious but also nutritious, packed with vitamins, fiber, and antioxidants. They are a versatile fruit, used in various culinary applications, from snacking to baking and making refreshing juices.");
        fruitData.put("Mango", "Mangoes are tropical fruits renowned for their rich, sweet, and exotic taste. They have a vibrant orange-yellow flesh and a large, flat pit in the center. Mangoes are often referred to as the king of fruits and are enjoyed fresh, in smoothies, salads, or as part of various dishes in many cuisines around the world.");
        fruitData.put("Orange", "Oranges are round citrus fruits with a bright orange peel and juicy, sweet-tart flesh. They are a popular source of vitamin C and are known for their refreshing, tangy flavor. Oranges are commonly consumed fresh as a snack or in the form of orange juice, and they add a burst of citrus goodness to both sweet and savory dishes.");
        fruitData.put("Banana", "Bananas are elongated, curved fruits with a soft, creamy interior covered by a yellow peel. They are one of the most widely consumed fruits globally and are prized for their natural sweetness and high potassium content. Bananas are a convenient and energy-boosting snack and are often used in smoothies, desserts, and baking.");
        fruitData.put("Strawberry", "Strawberries are small, red, heart-shaped berries known for their sweet and slightly tart taste. They are juicy and fragrant, making them a delightful addition to salads, desserts, and jams. Strawberries are not only delicious but also a good source of vitamin C and antioxidants.");
        fruitData.put("BlueBerry", "Blueberries are small, round berries with a deep blue-purple hue. They have a sweet and slightly tangy flavor and are packed with antioxidants, vitamins, and dietary fiber. Blueberries are commonly enjoyed fresh, added to cereals, yogurt, or baked into muffins, pies, and pancakes.");
        fruitData.put("Kiwi", "Kiwis are small, green fruits with fuzzy brown skin and vibrant green flesh speckled with tiny black seeds. They have a unique combination of sweet and slightly tangy flavors. Kiwis are known for their high vitamin C content and are often sliced and eaten as a refreshing snack or used in fruit salads and desserts.");
        fruitData.put("Dragon Fruit", "Dragon fruit, also known as pita, is an exotic fruit with a striking appearance. It has bright pink or yellow skin with green scales and white or red flesh studded with tiny black seeds. Dragon fruit has a mild, subtly sweet flavor and is often enjoyed fresh or added to smoothie bowls for a visually appealing and nutritious treat. It's known for its high content of vitamin C and fiber.");

        fruitList.add(new Item("Apple", R.drawable.apple));
        fruitList.add(new Item("Mango", R.drawable.mango));
        fruitList.add(new Item("Orange", R.drawable.orange));
        fruitList.add(new Item("Banana", R.drawable.banana));
        fruitList.add(new Item("Strawberry", R.drawable.strawberry));
        fruitList.add(new Item("BlueBerry", R.drawable.blueberry));
        fruitList.add(new Item("Kiwi", R.drawable.kiwi));
        fruitList.add(new Item("Dragon Fruit", R.drawable.dragonfruit));




        simpleList = findViewById(R.id.simpleListView);
        MyAdapter myAdapter = new MyAdapter(this, R.layout.list_view_item, fruitList);
        simpleList.setAdapter(myAdapter);

        simpleList.setOnItemClickListener((parent, view, position, id) -> {
            Item item = (Item) simpleList.getItemAtPosition(position);
            Toast.makeText(getBaseContext(), item.getFruitName(), Toast.LENGTH_SHORT).show();
            try {
                Intent intent = new Intent(MainActivity.this, Description.class);
                intent.putExtra(FRUIT_NAME, item.getFruitName());
                intent.putExtra(Description.FRUIT_DESCRIPTION, fruitData.get(item.getFruitName()));
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
