package com.example.assignment2;

public class Item {
    private final String fruitName;
    private final int imageResource;

    public Item(String fruitName, int imageResource) {
        this.fruitName = fruitName;
        this.imageResource = imageResource;
    }

    public String getFruitName() {
        return fruitName;
    }

    public int getImageResource() {
        return imageResource;
    }
}


