package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Description extends AppCompatActivity {

    public static final String FRUIT_DESCRIPTION = "FruitDescription";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);

        Button returnButton = findViewById(R.id.ReturnButton);
        TextView textView = findViewById(R.id.textDescription);

        Intent intent = getIntent();
        String fruitDescription = intent.getStringExtra(FRUIT_DESCRIPTION);

        textView.setText(fruitDescription);

        returnButton.setOnClickListener(v -> finish());
    }
}
