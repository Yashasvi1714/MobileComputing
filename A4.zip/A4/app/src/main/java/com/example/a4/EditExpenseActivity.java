package com.example.a4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditExpenseActivity extends AppCompatActivity {

    private EditText editDescription, editAmount, editDate, editCategory;
    private ExpenseDBHelper dbHelper;
    private long expenseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_expense);

        dbHelper = new ExpenseDBHelper(this);

        editDescription = findViewById(R.id.editDescription);
        editAmount = findViewById(R.id.editAmount);
        editDate = findViewById(R.id.editDate);
        editCategory = findViewById(R.id.editCategory);

        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            expenseId = extras.getLong("expenseId", -1);
            if (expenseId != -1) {
                populateFields(expenseId);
            }
        }

        btnSave.setOnClickListener(v -> saveChanges());

        btnCancel.setOnClickListener(v -> finish());
    }

    private void populateFields(long expenseId) {
        Expense currentExpense = dbHelper.getExpense(expenseId);
        if (currentExpense != null) {
            editDescription.setText(currentExpense.getDescription());
            editAmount.setText(String.valueOf(currentExpense.getAmount()));
            editDate.setText(currentExpense.getDate());
            editCategory.setText(currentExpense.getCategory());
        }
    }

    private void saveChanges() {
        String description = editDescription.getText().toString().trim();
        String amountStr = editAmount.getText().toString().trim();
        String date = editDate.getText().toString().trim();
        String category = editCategory.getText().toString().trim();

        if (!description.isEmpty() && !amountStr.isEmpty() && !date.isEmpty() && !category.isEmpty()) {
            try {
                double amount = Double.parseDouble(amountStr);
                Expense currentExpense = new Expense(expenseId, description, amount, date, category);

                int rowsAffected = dbHelper.updateExpense(currentExpense);

                if (rowsAffected > 0) {
                    setResult(RESULT_OK);
                    finish();
                } else {
                    showToast("Failed to update expense. Please try again.");
                }
            } catch (NumberFormatException e) {
                showToast("Invalid amount. Please enter a valid number.");
            }
        } else {
            showToast("Please fill in all fields.");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
