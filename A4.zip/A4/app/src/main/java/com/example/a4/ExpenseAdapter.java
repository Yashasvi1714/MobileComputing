package com.example.a4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class ExpenseAdapter extends ArrayAdapter<Expense> {

    public ExpenseAdapter(Context context, List<Expense> expenses) {
        super(context, 0, expenses);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_expense, parent, false);
        }

        Expense expense = getItem(position);

        if (expense != null) {
            TextView descriptionTextView = convertView.findViewById(R.id.descriptionTextView);
            TextView amountTextView = convertView.findViewById(R.id.amountTextView);
            TextView dateTextView = convertView.findViewById(R.id.dateTextView);
            TextView categoryTextView = convertView.findViewById(R.id.categoryTextView);

            descriptionTextView.setText(expense.getDescription());
            amountTextView.setText(String.valueOf(expense.getAmount()));
            dateTextView.setText(expense.getDate());
            categoryTextView.setText(expense.getCategory());
        }

        return convertView;
    }
}

