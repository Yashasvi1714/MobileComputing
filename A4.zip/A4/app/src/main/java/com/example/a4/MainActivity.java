package com.example.a4;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editDescription, editAmount, editDate, editCategory;
    private List<Expense> expenseList;
    private ArrayAdapter<Expense> adapter;
    private ExpenseDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new ExpenseDBHelper(this);

        editDescription = findViewById(R.id.editDescription);
        editAmount = findViewById(R.id.editAmount);
        editDate = findViewById(R.id.editDate);
        editCategory = findViewById(R.id.editCategory);

        Button btnSave = findViewById(R.id.btnSave);
        Button btnRefresh = findViewById(R.id.btnRefresh);

        ListView expensesListView = findViewById(R.id.expensesListView);
        expenseList = dbHelper.getAllExpenses();

        adapter = new ExpenseAdapter(this, expenseList);
        expensesListView.setAdapter(adapter);

        btnSave.setOnClickListener(v -> saveExpense());

        btnRefresh.setOnClickListener(v -> refreshExpenseList());

        //expensesListView.setOnCreateContextMenuListener((menu, v, menuInfo) -> getMenuInflater().inflate(R.menu.context_menu, menu));
        registerForContextMenu(expensesListView);

        expensesListView.setOnItemClickListener((parent, view, position, id) -> {
            // Handle item click here if needed
        });
    }

    private void saveExpense() {
        String description = editDescription.getText().toString().trim();
        String amountStr = editAmount.getText().toString().trim();
        String date = editDate.getText().toString().trim();
        String category = editCategory.getText().toString().trim();

        if (!description.isEmpty() && !amountStr.isEmpty() && !date.isEmpty() && !category.isEmpty()) {
            try {
                double amount = Double.parseDouble(amountStr);
                Expense newExpense = new Expense(0, description, amount, date, category);

                long insertedId = dbHelper.addExpense(newExpense);

                if (insertedId > 0) {
                    newExpense.setId(insertedId);
                    expenseList.add(newExpense);
                    adapter.notifyDataSetChanged();
                    clearInputFields();
                    showToast("Expense saved successfully");
                } else {
                    showToast("Failed to save expense. Please try again.");
                }
            } catch (NumberFormatException e) {
                showToast("Invalid amount. Please enter a valid number.");
            }
        } else {
            showToast("Please fill in all fields.");
        }
    }

    private void clearInputFields() {
        editDescription.getText().clear();
        editAmount.getText().clear();
        editDate.getText().clear();
        editCategory.getText().clear();
    }

    private void refreshExpenseList() {
        expenseList.clear();
        expenseList.addAll(dbHelper.getAllExpenses());
        adapter.notifyDataSetChanged();
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        assert info != null;
        int position = info.position;
        Expense selectedExpense = adapter.getItem(position);

        int itemId = item.getItemId();
        if (itemId == R.id.menu_edit) {
            assert selectedExpense != null;
            editExpense(selectedExpense);
            return true;
        } else if (itemId == R.id.menu_delete) {
            deleteExpense(selectedExpense);
            return true;
        } else if (itemId == R.id.menu_cancel) {
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }

    private void editExpense(Expense expense) {
        Intent intent = new Intent(this, EditExpenseActivity.class);
        intent.putExtra("expenseId", expense.getId()); // Pass only the ID
        startActivityForResult(intent, 1);
    }




    private void deleteExpense(Expense expense) {
        dbHelper.deleteExpense(expense);
        refreshExpenseList();
        showToast("Expense deleted successfully");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            refreshExpenseList();
            showToast("Expense updated successfully");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
