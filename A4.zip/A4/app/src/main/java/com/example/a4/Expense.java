package com.example.a4;

import androidx.annotation.NonNull;

public class Expense {
    private long id;
    private String description;
    private double amount;
    private String date;
    private String category;
    // Constructor
    public Expense() { }
    public Expense(long id, String description, double amount, String date, String
            category) {
        this.id = id;
        this.description = description;
        this.amount = amount;
        this.date = date;
        this.category = category;
    }
    // Getters
    public long getId() { return id; }
    public String getDescription() { return description; }
    public double getAmount() { return amount; }
    public String getDate() { return date; }
    public String getCategory() { return category; }
    // Setters
    public void setId(long id) { this.id = id; }
    public void setDescription(String description) { this.description =
            description; }
    public void setAmount(double amount) { this.amount = amount; }
    public void setDate(String date) { this.date = date; }
    public void setCategory(String category) { this.category = category; }
    @NonNull
    @Override
    public String toString() {
        return "Expense{" + "id=" + id + ", description='" + description + '\'' +
                ", amount=" + amount +
                ", date='" + date + '\'' + ", category='" + category + '\'' + '}';
    }
}

